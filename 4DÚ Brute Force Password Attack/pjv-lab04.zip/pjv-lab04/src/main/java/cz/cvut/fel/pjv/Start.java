package cz.cvut.fel.pjv;

public class Start {

    public static void main(String[] args) {
        
            Test hw = new Test();
            hw.start();
    }
}
