/*
 * File name: Lab06.java
 * Date:      2014/08/26 21:39
 * Author:    @author
 */

package cz.cvut.fel.pjv;

import java.util.Scanner;

public class Lab02 {


  
   public void start(String[] args) {
    
	   

   }
}

/* end of Lab02.java */
